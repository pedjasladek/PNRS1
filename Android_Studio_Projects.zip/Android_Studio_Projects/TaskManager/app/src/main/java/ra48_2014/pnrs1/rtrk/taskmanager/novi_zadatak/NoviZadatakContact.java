package ra48_2014.pnrs1.rtrk.taskmanager.novi_zadatak;

/**
 * Created by VELIKI on 3/30/2017.
 */

public class NoviZadatakContact {

    public interface View {

        void dialogTimeDate();

        void proceedOnMainActivity();

        void disableYellowAndGreen();
        void disableRedAndGreen();
        void disableRedAndYellow();

        void toastAdd();
        void toastCancel();
        void toastEmpty();
        void toastRed();
        void toastYellow();
        void toastGreen();
        void toastTime(int hourOfDay, int minute);
        void toastDate(int year, int month, int dayOfMonth);
        void toastCheckBox();
    }

    public interface Presenter {

    }

}
