package ra48_2014.pnrs1.rtrk.taskmanager.task_manager_main;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import ra48_2014.pnrs1.rtrk.taskmanager.R;
import ra48_2014.pnrs1.rtrk.taskmanager.novi_zadatak.NoviZadatakActivity;
import ra48_2014.pnrs1.rtrk.taskmanager.statistika.StatistikaActivity;

public class MainActivity extends AppCompatActivity implements MainContact.View{

    Button new_task_btn, stats_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        new_task_btn = (Button) findViewById(R.id.new_task_btn);
        stats_btn = (Button) findViewById(R.id.stats_btn);

        /* Called when the user presses "Novi zadatak" button */

        new_task_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                proceedOnNewTaskActivity();
            }
        });

        /* Called when the user presses "Statistika" button */

        stats_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               proceedOnStatsTaskActivity();
            }
        });

    }

    /* Jumps to new to MainActivity */

    @Override
    public void proceedOnNewTaskActivity() {
        Intent intent = new Intent(MainActivity.this, NoviZadatakActivity.class);
        startActivity(intent);
    }

    @Override
    public void proceedOnStatsTaskActivity() {
        Intent intent = new Intent(MainActivity.this, StatistikaActivity.class);
        startActivity(intent);

    }

}
