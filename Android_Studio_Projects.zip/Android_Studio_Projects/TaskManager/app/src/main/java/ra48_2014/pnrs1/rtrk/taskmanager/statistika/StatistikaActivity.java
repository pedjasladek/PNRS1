package ra48_2014.pnrs1.rtrk.taskmanager.statistika;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import ra48_2014.pnrs1.rtrk.taskmanager.R;

public class StatistikaActivity extends AppCompatActivity implements StatistikaContact.View{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistika);
    }
}
