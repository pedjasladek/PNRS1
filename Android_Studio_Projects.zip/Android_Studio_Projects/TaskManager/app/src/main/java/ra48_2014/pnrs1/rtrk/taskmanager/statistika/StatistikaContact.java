package ra48_2014.pnrs1.rtrk.taskmanager.statistika;

/**
 * Created by VELIKI on 3/30/2017.
 */

public class StatistikaContact {

    public interface View{

    }

    public interface Presenter{

    }

}
