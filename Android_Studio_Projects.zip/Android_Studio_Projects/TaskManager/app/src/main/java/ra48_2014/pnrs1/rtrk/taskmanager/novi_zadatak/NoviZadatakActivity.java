package ra48_2014.pnrs1.rtrk.taskmanager.novi_zadatak;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.sql.Time;
import java.util.Calendar;

import ra48_2014.pnrs1.rtrk.taskmanager.R;
import ra48_2014.pnrs1.rtrk.taskmanager.task_manager_main.MainActivity;

public class NoviZadatakActivity extends AppCompatActivity implements NoviZadatakContact.View{

    private Button add_btn;
    private Button cancel_btn;
    private Button red_btn;
    private Button yellow_btn;
    private Button green_btn;
    private Button time_date_btn;

    private TimePickerDialog.OnTimeSetListener onTimeSetListener;
    private DatePickerDialog.OnDateSetListener onDateSetListener;

    private EditText name_txt;
    private EditText description_txt;

    private TextView time_txt;
    private TextView date_txt;

    private CheckBox check_box;

    private boolean flag = false;
    private boolean flag1 = false;
    private boolean flag2 = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_novi_zadatak);

        add_btn = (Button) findViewById(R.id.add_btn);
        cancel_btn = (Button) findViewById(R.id.cancel_btn);
        red_btn = (Button) findViewById(R.id.red_btn);
        yellow_btn = (Button) findViewById(R.id.yellow_btn);
        green_btn = (Button) findViewById(R.id.green_btn);
        name_txt = (EditText) findViewById(R.id.new_task_txt);
        description_txt = (EditText) findViewById(R.id.description_txt);
        time_date_btn = (Button) findViewById(R.id.time_date_btn);
        time_txt = (TextView) findViewById(R.id.time_txt);
        date_txt = (TextView) findViewById(R.id.date_txt);
        check_box = (CheckBox) findViewById(R.id.check_box);

        /* Called when the user presses "Vreme i datum" button */

        time_date_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialogTimeDate();
            }
        });

        /* Called when the user presses red button */

        red_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                disableYellowAndGreen();
                toastRed();
            }
        });

        /* Called when the user presses yellow button */

        yellow_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                disableRedAndGreen();
                toastYellow();
            }
        });

        /* Called when the user presses green button */

        green_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                disableRedAndYellow();
                toastGreen();
            }
        });

        /* Called when the user is done setting a new time and the dialog has closed. */

        onTimeSetListener = new OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                time_txt.setText(Integer.toString(hourOfDay) + "h : " + Integer.toString(minute) + "m");
                toastTime(hourOfDay, minute);
                flag1 = true;
            }
        };

        /* Called when the user is done setting a new date and the dialog has closed. */

        onDateSetListener = new OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                date_txt.setText(Integer.toString(dayOfMonth) + " - " + Integer.toString(month) + " - " + Integer.toString(year));
                toastDate(year, month, dayOfMonth);
                flag2 = true;
            }
        };

        /* Called when the user presses "Dodaj" button */

        add_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(flag && flag1 && flag2 && !name_txt.getText().toString().isEmpty() && !description_txt.getText().toString().isEmpty()){
                    proceedOnMainActivity();
                    toastAdd();
                }else{
                    toastEmpty();
                }
            }
        });

        /* Called when the user presses "Otkazi" button */

        cancel_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                proceedOnMainActivity();
                toastCancel();
            }
        });

        /* Called when user presses on check box */

        check_box.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toastCheckBox();
            }
        });
    }

    /* Gets current date, time and opens date and time dialogs*/

    @Override
    public void dialogTimeDate() {

        Calendar c = Calendar.getInstance();
        new TimePickerDialog(NoviZadatakActivity.this, onTimeSetListener, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show();
        new DatePickerDialog(NoviZadatakActivity.this, onDateSetListener, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();

    }

    /* Jumps to new to MainActivity */

    @Override
    public void proceedOnMainActivity() {
        Intent intent = new Intent(NoviZadatakActivity.this, MainActivity.class);
        startActivity(intent);
    }

    /* Disables yellow and green button */

    @Override
    public void disableYellowAndGreen() {
        yellow_btn.setEnabled(false);
        green_btn.setEnabled(false);
        flag = true;
    }

    /* Disables red and green button */

    @Override
    public void disableRedAndGreen() {
        red_btn.setEnabled(false);
        green_btn.setEnabled(false);
        flag = true;
    }

    /* Disables red and yellow button */

    @Override
    public void disableRedAndYellow() {
        red_btn.setEnabled(false);
        yellow_btn.setEnabled(false);
        flag = true;
    }

    /* Toast messages */

    @Override
    public void toastAdd() {
        Toast.makeText(this, "Dodali ste zadatak", Toast.LENGTH_LONG).show();
    }

    @Override
    public void toastCancel() {
        Toast.makeText(this, "Zadatak je otkazan", Toast.LENGTH_LONG).show();
    }

    @Override
    public void toastEmpty() {
        Toast.makeText(this, "Niste popunili sva polja", Toast.LENGTH_LONG).show();
    }

    @Override
    public void toastRed() {
        Toast.makeText(this, "Zuti i zeleni tasteri su iskljuceni", Toast.LENGTH_LONG).show();
    }

    @Override
    public void toastYellow() {
        Toast.makeText(this, "Crveni i zeleni tasteri su iskljuceni", Toast.LENGTH_LONG).show();
    }

    @Override
    public void toastGreen() {
        Toast.makeText(this, "Crveni i zuti tasteri su iskljuceni", Toast.LENGTH_LONG).show();
    }

    @Override
    public void toastTime(int hourOfDay, int minute) {
        Toast.makeText(this, "Vreme: " + Integer.toString(hourOfDay) + "h : " + Integer.toString(minute) + "m", Toast.LENGTH_LONG).show();
    }

    @Override
    public void toastDate(int year, int month, int dayOfMonth) {
        Toast.makeText(this, "Datum: " + Integer.toString(year) + " - " + Integer.toString(month) + " - " + Integer.toString(dayOfMonth), Toast.LENGTH_LONG).show();
    }

     /* Checking if check box is selected or not */

    @Override
    public void toastCheckBox() {
        if(check_box.isChecked()){
            Toast.makeText(this, "Podsecanje 15 minute pre isteka ukljuceno", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(this, "Podsecanje 15 minute pre isteka iskljuceno", Toast.LENGTH_LONG).show();
        }
    }

}
