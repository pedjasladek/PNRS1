package ra48_2014.pnrs1.rtrk.taskmanager.task_manager_main;

/**
 * Created by VELIKI on 3/30/2017.
 */

public class MainContact {

    public interface View {
        void proceedOnNewTaskActivity();
        void proceedOnStatsTaskActivity();
    }

    public interface Presenter {

    }

}
