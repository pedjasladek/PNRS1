package ra48_2014.pnrs1.rtrk.taskmanager.task_manager_main;

/**
 * Created by VELIKI on 3/30/2017.
 */

public class MainPresenter implements MainContact.Presenter {

}
