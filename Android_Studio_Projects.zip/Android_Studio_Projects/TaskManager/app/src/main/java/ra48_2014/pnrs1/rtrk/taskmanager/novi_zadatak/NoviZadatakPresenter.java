package ra48_2014.pnrs1.rtrk.taskmanager.novi_zadatak;

/**
 * Created by VELIKI on 3/30/2017.
 */

public class NoviZadatakPresenter implements NoviZadatakContact.Presenter{

}
